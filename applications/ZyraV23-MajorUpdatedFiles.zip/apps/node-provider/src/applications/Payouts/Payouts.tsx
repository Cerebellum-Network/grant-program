import { observable } from 'mobx';

const Payouts = () => {
  return <div>AAA</div>;
};

export default observable(Payouts);
