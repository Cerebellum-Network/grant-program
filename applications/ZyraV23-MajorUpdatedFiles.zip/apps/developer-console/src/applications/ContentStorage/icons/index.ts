export * from './DataStorageDocsIcon';
