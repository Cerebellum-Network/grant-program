import { Typography } from '@cluster-apps/ui';
import { observer } from 'mobx-react-lite';

const ActivityCapture = () => <Typography>Coming Soon...</Typography>;

export default observer(ActivityCapture);
