export const SENTRY_DNS = import.meta.env.VITE_SENTRY_DNS || '';
