import AuthController from './auth.controller';

// Exportar controladores
export { default as authController } from './auth.controller';
export { default as paymentController } from './payment.controller'; 