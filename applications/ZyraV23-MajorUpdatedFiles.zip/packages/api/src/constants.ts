export const INDEXER_ENDPOINT = import.meta.env.VITE_INDEXER_ENDPOINT || '';
export const FAUCET_ENDPOINT = import.meta.env.VITE_FAUCET_ENDPOINT || '';
export const STATS_ENDPOINT = import.meta.env.VITE_STATS_ENDPOINT || '';
export const CLUSTER_MANAGEMENT_ENDPOINT = import.meta.env.VITE_CLUSTER_MANAGEMENT_ENDPOINT || '';
