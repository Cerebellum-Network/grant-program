export const GTM_ID = import.meta.env.VITE_GTM_ID || '';
